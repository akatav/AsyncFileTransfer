/* @flow */

function length(x) {
  return x.length;
}

var total = length("Hello") + length(null);
