/* @flow */

function foo(x) {
  return x*10;
}

// This is fine, because we're passing a number now
foo(10);
