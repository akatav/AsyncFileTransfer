//Provides: hh_counter_next
var __hh_counter = 0;
function hh_counter_next() {
  return ++__hh_counter;
}
