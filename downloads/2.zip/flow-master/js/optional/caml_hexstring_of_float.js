//Provides: caml_hexstring_of_float
function caml_hexstring_of_float() {
  // https://github.com/ocsigen/js_of_ocaml/issues/403
  // Should be available when js_of_ocaml 2.8 is released
  throw new Error('caml_hexstring_of_float: not implemented in JS');
}
