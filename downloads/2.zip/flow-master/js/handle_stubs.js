//Provides: win_setup_handle_serialization
function win_setup_handle_serialization() {
  return;
}
