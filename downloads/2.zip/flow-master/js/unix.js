//Provides: caml_channel_descriptor
function caml_channel_descriptor() {
  throw new Error('caml_channel_descriptor: not implemented in JS');
}

//Provides: unix_getpid const
function unix_getpid() {
  return 0;
}

//Provides: unix_alarm
function unix_alarm() {
  throw new Error('unix_alarm: not implemented in JS');
}

//Provides: unix_clear_nonblock
function unix_clear_nonblock() {
  throw new Error('unix_clear_nonblock: not implemented in JS');
}

//Provides: unix_close
function unix_close() {
  throw new Error('unix_close: not implemented in JS');
}

//Provides: unix_connect
function unix_connect() {
  throw new Error('unix_connect: not implemented in JS');
}

//Provides: unix_dup
function unix_dup() {
  throw new Error('unix_dup: not implemented in JS');
}

//Provides: unix_dup2
function unix_dup2() {
  throw new Error('unix_dup2: not implemented in JS');
}

//Provides: unix_execvp
function unix_execvp() {
  throw new Error('unix_execvp: not implemented in JS');
}

//Provides: unix_fork
function unix_fork() {
  throw new Error('unix_fork: not implemented in JS');
}

//Provides: unix_kill
function unix_kill() {
  throw new Error('unix_kill: not implemented in JS');
}

//Provides: unix_open
function unix_open() {
  throw new Error('unix_open: not implemented in JS');
}

//Provides: unix_pipe
function unix_pipe() {
  throw new Error('unix_pipe: not implemented in JS');
}

//Provides: unix_read
function unix_read() {
  throw new Error('unix_read: not implemented in JS');
}

//Provides: unix_select
function unix_select() {
  throw new Error('unix_select: not implemented in JS');
}

//Provides: unix_set_close_on_exec
function unix_set_close_on_exec() {
  throw new Error('unix_set_close_on_exec: not implemented in JS');
}

//Provides: unix_set_nonblock
function unix_set_nonblock() {
  throw new Error('unix_set_nonblock: not implemented in JS');
}

//Provides: unix_shutdown
function unix_shutdown() {
  throw new Error('unix_shutdown: not implemented in JS');
}

//Provides: unix_socket
function unix_socket() {
  throw new Error('unix_socket: not implemented in JS');
}

//Provides: unix_waitpid
function unix_waitpid() {
  throw new Error('unix_waitpid: not implemented in JS');
}
