//Provides: win_terminate_process
function win_terminate_process() {
  throw new Error('win_terminate_process: not implemented in JS');
}
