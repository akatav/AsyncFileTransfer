//Provides: hh_sysinfo_totalram const
function hh_sysinfo_totalram() {
  return 0;
}
