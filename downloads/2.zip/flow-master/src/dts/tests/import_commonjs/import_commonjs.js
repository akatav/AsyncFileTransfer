// @flow
var P = require("module-P");
var x : string = (new P.C()).y;
var M = require("M");
var z: number = M.m;
