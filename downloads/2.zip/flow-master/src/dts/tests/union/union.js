// @flow
var a : number = x;
var b : typeof x = 5;
