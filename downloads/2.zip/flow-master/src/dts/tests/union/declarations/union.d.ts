declare var x : number | string;
