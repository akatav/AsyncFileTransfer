declare module M.N {
    export var x: number
    export class C {
        y : typeof x
    }
}
