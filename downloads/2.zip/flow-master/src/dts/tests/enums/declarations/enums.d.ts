declare enum Color {
    R, G, B
}
