// @flow
var z : string = x["0"];
