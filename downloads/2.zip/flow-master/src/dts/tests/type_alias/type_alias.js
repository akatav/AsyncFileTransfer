// @flow
var M = require('M');
var a : number = M.x;
var b : typeof M.x = 5;
