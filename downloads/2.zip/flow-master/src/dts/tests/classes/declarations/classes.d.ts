declare class C {
    x : number
}

declare class D extends C {
    y : string
}
