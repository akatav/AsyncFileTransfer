// @flow

import {Child} from "./named_class_exports";

export const a: Child<number, string> = new Child();
