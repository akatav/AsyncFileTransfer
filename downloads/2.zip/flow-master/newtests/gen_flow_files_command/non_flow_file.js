export function addNum(a: number, b: number) { return a + b; }
