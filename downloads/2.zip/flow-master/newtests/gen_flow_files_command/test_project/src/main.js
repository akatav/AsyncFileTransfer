// @flow

export const name: "main.js" = "main.js";
