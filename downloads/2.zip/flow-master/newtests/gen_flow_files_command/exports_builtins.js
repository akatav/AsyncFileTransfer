// @flow

export function fn(a: Array<number>) {};
