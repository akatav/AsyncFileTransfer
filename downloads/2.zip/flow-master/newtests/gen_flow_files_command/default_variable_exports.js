// @flow

export default 42;
export const str = "asdf";
