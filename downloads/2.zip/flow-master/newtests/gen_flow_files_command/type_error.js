// @flow

export var a: string = 42;
