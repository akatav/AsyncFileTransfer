// @flow

// $FlowFixMe
export function fn() { return ('asdf': number); };
