/*  */

function foo(f: Function) {
  f.
}
