/*  */

function foo(f: () => number) {
  f.
}
