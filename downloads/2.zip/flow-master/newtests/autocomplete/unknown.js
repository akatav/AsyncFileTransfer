// @noflow
module.exports = { x: { y: "" } };
