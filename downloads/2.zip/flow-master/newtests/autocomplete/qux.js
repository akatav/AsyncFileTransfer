//

class C { x: number; }

var c: C = new C;
c.
