/*  */

// issue #1197
class Foo {
  baz: string;
  bar() {}
  hello() {
    this.
  }
}
