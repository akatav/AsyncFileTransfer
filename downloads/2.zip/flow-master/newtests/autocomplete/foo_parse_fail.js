/**
 *
 */

var obj = {
  num: 123,
  str: 'hello',
};

console.log(obj.
