//

var React = require('react');

class C extends React.Component {
  props: { x: number };
}
<C // Putting a comment here so the space after C doesn't get trimmed
