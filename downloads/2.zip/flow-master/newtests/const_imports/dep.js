export default 42;
export var named = 'asdf';
