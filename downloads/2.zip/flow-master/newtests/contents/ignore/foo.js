require('./dummy');
var xxx = 0;
xxx
