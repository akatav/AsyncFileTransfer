/**
 * Dupe provider 2/2
 * @providesModule Dupe
 * @thisWillBeFlowInTest
 */
module.exports = "dupe2";
