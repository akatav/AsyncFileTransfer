/**
 * Dupe provider 1/2
 * @providesModule Dupe
 * @thisWillBeFlowInTest
 */
module.exports = "dupe1";
