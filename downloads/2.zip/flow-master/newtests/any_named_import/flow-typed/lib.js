declare module 'any' {
  declare module.exports: any;
}

declare module 'object' {
  declare module.exports: Object;
}


declare module 'string' {
  declare module.exports: string;
}
