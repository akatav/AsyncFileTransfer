// Let's pretend that require('blah.css') returns a boolean
declare module.exports: boolean;
