export default 123;
