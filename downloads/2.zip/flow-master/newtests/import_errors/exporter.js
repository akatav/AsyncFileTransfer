// @flow

export default 42;
